import java.util.Scanner;

public class Addition {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number For Sum");
		int num1=sc.nextInt();
		
		System.out.println("Enter the number 2 for Sum");
		int num2=sc.nextInt();
		
		System.out.println("The Sum is "+(num1+num2));

	}

}
