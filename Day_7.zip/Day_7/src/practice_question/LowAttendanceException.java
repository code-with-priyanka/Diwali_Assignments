package practice_question;


public class LowAttendanceException extends Exception {
 public LowAttendanceException(String message) {
     super(message);
 }
}
