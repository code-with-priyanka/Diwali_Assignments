package study;

public class WrongOperatorException extends Exception {
 public WrongOperatorException(String message) {
     super(message);
 }
}

